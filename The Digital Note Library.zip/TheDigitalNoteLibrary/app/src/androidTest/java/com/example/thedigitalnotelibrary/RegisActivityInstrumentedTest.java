//package com.example.thedigitalnotelibrary;
//
//import android.content.Intent;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ProgressBar;
//import android.widget.TextView;
//
//import androidx.test.core.app.ActivityScenario;
//import androidx.test.espresso.Espresso;
//import androidx.test.espresso.action.ViewActions;
//import androidx.test.espresso.matcher.RootMatchers;
//import androidx.test.espresso.matcher.ViewMatchers;
//import androidx.test.ext.junit.rules.ActivityScenarioRule;
//import androidx.test.ext.junit.runners.AndroidJUnit4;
//
//import org.junit.Before;
//import org.junit.Rule;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//
//import static androidx.test.espresso.assertion.ViewAssertions.matches;
//import static androidx.test.espresso.matcher.ViewMatchers.*;
//import static org.hamcrest.Matchers.not;
//
//@RunWith(AndroidJUnit4.class)
//public class RegisActivityInstrumentedTest {
//
//    @Rule
//    public ActivityScenarioRule<RegisActivity> activityScenarioRule =
//            new ActivityScenarioRule<>(RegisActivity.class);
//
//    private EditText usernameEditText, emailEditText, passwordEditText, confirmPasswordEditText;
//    private Button submitBtn;
//    private ProgressBar progressBar;
//    private TextView loginBtnTextView, adminLoginBtnTextView;
//
//    @Before
//    public void setUp() {
//        // Initialize view references
//        ActivityScenario<RegisActivity> activityScenario = activityScenarioRule.getScenario();
//        activityScenario.onActivity(activity -> {
//            usernameEditText = activity.findViewById(R.id.user_name_edit_text);
//            emailEditText = activity.findViewById(R.id.email_edit_text);
//            passwordEditText = activity.findViewById(R.id.password_edit_text);
//            confirmPasswordEditText = activity.findViewById(R.id.confirm_password_edit_text);
//            submitBtn = activity.findViewById(R.id.submit_btn);
//            progressBar = activity.findViewById(R.id.progress_bar);
//            loginBtnTextView = activity.findViewById(R.id.login_text_view_btn);
//            adminLoginBtnTextView = activity.findViewById(R.id.admin_click_here_btn);
//        });
//    }
//
//
//    @Test
//    public void testRegistration_Successful() {
//        // Perform actions for successful registration
//        Espresso.onView(ViewMatchers.withId(R.id.user_name_edit_text)).perform(ViewActions.typeText("test_user"));
//        Espresso.onView(ViewMatchers.withId(R.id.email_edit_text)).perform(ViewActions.typeText("test@example.com"));
//        Espresso.onView(ViewMatchers.withId(R.id.password_edit_text)).perform(ViewActions.typeText("password123"));
//        Espresso.onView(ViewMatchers.withId(R.id.confirm_password_edit_text)).perform(ViewActions.typeText("password123"));
//        Espresso.onView(ViewMatchers.withId(R.id.submit_btn)).perform(ViewActions.click());
//
//        // Check if progress bar is visible
//        Espresso.onView(ViewMatchers.withId(R.id.progress_bar)).check(matches(isDisplayed()));
//
//        // Check if submit button is hidden
//        Espresso.onView(ViewMatchers.withId(R.id.submit_btn)).check(matches(not(isDisplayed())));
//    }
//
//    @Test
//    public void testRegistration_Failed_InvalidEmail() {
//        // Perform actions for registration with invalid email
//        Espresso.onView(ViewMatchers.withId(R.id.email_edit_text)).perform(ViewActions.typeText("invalid_email"));
//        Espresso.onView(ViewMatchers.withId(R.id.password_edit_text)).perform(ViewActions.typeText("password123"));
//        Espresso.onView(ViewMatchers.withId(R.id.confirm_password_edit_text)).perform(ViewActions.typeText("password123"));
//        Espresso.onView(ViewMatchers.withId(R.id.submit_btn)).perform(ViewActions.click());
//
//        // Check if error message for invalid email is displayed
//        //Espresso.onView(ViewMatchers.withText("Invalid Email")).check(matches(isDisplayed()));
//
//        // Check if progress bar is not visible
//        Espresso.onView(ViewMatchers.withId(R.id.progress_bar)).check(matches(not(isDisplayed())));
//
//        // Check if submit button is visible
//        Espresso.onView(ViewMatchers.withId(R.id.submit_btn)).check(matches(isDisplayed()));
//    }
//
//    // Add more test cases for other scenarios as needed
//}
