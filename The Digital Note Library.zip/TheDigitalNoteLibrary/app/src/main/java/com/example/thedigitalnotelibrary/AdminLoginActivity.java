package com.example.thedigitalnotelibrary;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class AdminLoginActivity extends AppCompatActivity {
    //fields

    EditText email, username, password, dob, passcode;
    Button submitBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_login);

        email = findViewById(R.id.admin_email_edit_text);
        username = findViewById(R.id.admin_username_edit_text);
        password = findViewById(R.id.admin_password_edit_text);
        passcode = findViewById(R.id.admin_passcode_edit_text);
        dob = findViewById(R.id.admin_dob_edit_text);
        submitBtn = findViewById(R.id.admin_login_btn);

        submitBtn.setOnClickListener(v -> submitDetails());
    }

    void submitDetails() {
        //user input is collected
        String admin_email = email.getText().toString();
        String admin_username = username.getText().toString();
        String admin_password = password.getText().toString();
        String admin_passcode = passcode.getText().toString();
        String admin_dob = dob.getText().toString();

        //user input is validated
        boolean isValid = validate(admin_email, admin_username, admin_password,
                Integer.parseInt(admin_passcode), admin_dob);

        //outcome based on validation
        if (isValid) {
            adminLogin(admin_email, admin_password);
        } else {
            Utility.showToast(AdminLoginActivity.this,
                    "One or more of your answers are incorrect");
        }
    }

    void adminLogin(String email, String password) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Utility.showToast(AdminLoginActivity.this, "Login Successful");
                    startActivity(new Intent(AdminLoginActivity.this,
                            AdminDashboardActivity.class));
                } else {
                    Utility.showToast(AdminLoginActivity.this, "Problem signing in.");
                }

            }
        });
    }

    Boolean validate(String email, String username, String password, Integer passcode, String dob) {
        return email.equals("exzitin@gmail.com") && password.equals("0568928517Banana!") &&
                username.equals("Nusaiba Amin") && passcode == 255961 && dob.equals("01/09/2000");
    }
}
