package com.example.thedigitalnotelibrary;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import java.util.ArrayList;
import java.util.Arrays;


public class UploadFormActivity extends AppCompatActivity {

    EditText subjectEditText, yearEditText, authorEditText;
    MaterialButton uploadBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload_form);

        subjectEditText = findViewById(R.id.subject_edit_text);
        yearEditText = findViewById(R.id.year_edit_text);
        authorEditText = findViewById(R.id.author_edit_text);
        uploadBtn = findViewById(R.id.upload_form_btn);

        uploadBtn.setOnClickListener( v -> uploadToPublicLibrary());
    }

    Boolean validateUploadNoteForm(String year, String subject, String author) {
        //validating all input
        if (author.isEmpty() || !(Utility.doesNotContainSpecialChars(author))){
            this.authorEditText.setError("Invalid Author Name");
            return false;
        }

        if (subject.isEmpty() || !(Utility.doesNotContainSpecialChars(subject))){
            this.subjectEditText.setError("Invalid Subject Name");
            return false;
        }

        if (year.isEmpty() || (Utility.doesNotContainNumbers(year)) || year.length() > 2) {
            this.yearEditText.setError("Invalid Year Digit");
            return false;
        }
        return true;
    }

    void uploadToPublicLibrary() {
        //get the note's title, content, and timestamp, bind it to the preview note
        //xml's parts, and save it in the public library
        String noteTitle = getIntent().getStringExtra("title");
        String noteContent = getIntent().getStringExtra("content");
        String noteYear = yearEditText.getText().toString();
        String noteSubject = subjectEditText.getText().toString().toLowerCase();
        String noteAuthor = authorEditText.getText().toString().toLowerCase();

        if (validateUploadNoteForm(noteYear, noteSubject, noteAuthor)) {
            Note note = new Note();
            note.setTitle(noteTitle);
            note.setContent(noteContent);
            note.setTimestamp(Timestamp.now());
            note.setYear(Integer.parseInt(noteYear));
            note.setAuthor(noteAuthor);
            note.setSubject(noteSubject);
            //add all the fields to the keywords array
            String[] keywords = noteSubject.toLowerCase().split(" ");
            ArrayList<String> keywordsArray = new ArrayList<>(Arrays.asList(keywords));
            note.setKeywords(keywordsArray);

            String[] titleArray = noteTitle.toLowerCase().split(" ");
            for(String s: titleArray){
                note.getKeywords().add(s);
            }

            String[] authorArray = noteAuthor.toLowerCase().split(" ");
            for(String s: authorArray){
                note.getKeywords().add(s);
            }
            note.getKeywords().add(noteYear);
            // as nobody has downloaded the note yet
            note.setDownloads(0);
            savePublicNoteToFirebase(note);
        } else {
            Utility.showToast(UploadFormActivity.this,"Oops! Incorrect form field(s)");
        }
    }

    void savePublicNoteToFirebase(Note note){
        DocumentReference documentReference;

        //create new note
        documentReference = Utility.getCollectionReferenceForPublicNotes().document();
        documentReference.set(note).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    //note is added
                    Utility.showToast(UploadFormActivity.this,
                            "Yay! Note added to public library successfully");
                    finish();
                }else{
                    Utility.showToast(UploadFormActivity.this,
                            "Oops! Failed while adding note");
                }
            }
        });

    }
}
