//package com.example.thedigitalnotelibrary;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import static org.junit.Assert.*;
//import static org.mockito.Mockito.*;
//
//import android.widget.EditText;
//
//public class RegisActivityTest {
//
//    @Mock
//    private EditText usernameEditText;
//    @Mock
//    private EditText emailEditText;
//    @Mock
//    private EditText passwordEditText;
//    @Mock
//    private EditText confirmPasswordEditText;
//
//    private RegisActivity activity;
//
//    @Before
//    public void setUp() {
//        MockitoAnnotations.initMocks(this);
//        activity = new RegisActivity();
//        activity.usernameEditText = usernameEditText;
//        activity.emailEditText = emailEditText;
//        activity.passwordEditText = passwordEditText;
//        activity.confirmPasswordEditText = confirmPasswordEditText;
//    }
//
//    @Test
//    public void testValidateRegisForm_ValidData() {
//        // Given valid data
//        String username = "test_user";
//        String email = "test@example.com";
//        String password = "password123";
//        String confirmPassword = "password123";
//
//        // When validateRegisForm is called
//        boolean result = activity.validateRegisForm(username, email, password, confirmPassword);
//
//        // Then the result should be true
//        assertTrue(result);
//    }
//
//    @Test
//    public void testValidateRegisForm_InvalidData() {
//        // Given invalid data (in this case, invalid email)
//        String username = "test_user";
//        String email = "invalid_email";
//        String password = "password";
//        String confirmPassword = "password123";
//
//        // When validateRegisForm is called
//        boolean result = activity.validateRegisForm(username, email, password, confirmPassword);
//
//        // Then the result should be false
//        assertFalse(result);
//
//        // Verify that setError method is called with the correct error message
//        verify(emailEditText).setError("Invalid Email");
//    }
//
//    // Add more tests for other invalid scenarios if needed
//}
